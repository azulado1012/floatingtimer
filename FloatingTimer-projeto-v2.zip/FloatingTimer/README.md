# Floating Timer

Cronômetro Android nativo em Kotlin. A cápsula aparece sobre outros aplicativos e pode ser arrastada.

- Um toque: iniciar ou pausar (o toque simples é confirmado após 280 ms para detectar o duplo toque).
- Dois toques rápidos: zerar e iniciar novamente.
- Arrastar: mover a cápsula pela tela.

## Compilar pelo GitHub Actions

Envie o arquivo `FloatingTimer.zip` para a raiz do repositório e crie o workflow em `.github/workflows/android.yml` usando o conteúdo fornecido na conversa. O workflow extrai o ZIP e compila `assembleDebug`.

Na primeira abertura, toque em **Ativar cronômetro flutuante**, conceda a permissão de sobreposição e volte ao app. Toque novamente no botão para iniciar a cápsula.
