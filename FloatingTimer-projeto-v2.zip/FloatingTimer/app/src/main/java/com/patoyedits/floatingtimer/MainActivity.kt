package com.patoyedits.floatingtimer

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 64, 40, 40)
            setBackgroundColor(0xFF101010.toInt())
        }
        val title = TextView(this).apply {
            text = "Floating Timer"
            textSize = 28f
            setTextColor(0xFFFFFFFF.toInt())
        }
        val description = TextView(this).apply {
            text = "Cronômetro flutuante\n\n1 toque: iniciar ou pausar\n2 toques rápidos: zerar e iniciar\n\nVocê pode arrastar a cápsula pela tela."
            textSize = 16f
            setTextColor(0xFFCCCCCC.toInt())
            setPadding(0, 24, 0, 32)
        }
        val button = Button(this).apply {
            text = "Ativar cronômetro flutuante"
            setOnClickListener {
                if (Settings.canDrawOverlays(this@MainActivity)) {
                    val service = Intent(this@MainActivity, TimerOverlayService::class.java)
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        startForegroundService(service)
                    } else {
                        startService(service)
                    }
                    finish()
                } else {
                    startActivity(
                        Intent(
                            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                            Uri.parse("package:$packageName")
                        )
                    )
                }
            }
        }
        layout.addView(title)
        layout.addView(description)
        layout.addView(button)
        setContentView(layout)
    }
}
