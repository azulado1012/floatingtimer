package com.patoyedits.floatingtimer

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.TextView
import kotlin.math.abs

class TimerOverlayService : Service() {
    private lateinit var windowManager: WindowManager
    private lateinit var timerView: TextView
    private val handler = Handler(Looper.getMainLooper())
    private var startedAt = 0L
    private var elapsedBeforeStart = 0L
    private var running = false
    private var attached = false
    private var pendingTap: Runnable? = null
    private var downRawX = 0
    private var downRawY = 0
    private var initialX = 0
    private var initialY = 0
    private var moved = false

    private val ticker = object : Runnable {
        override fun run() {
            if (running) {
                renderTime()
                handler.postDelayed(this, 200L)
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        startAsForeground()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager

        timerView = TextView(this).apply {
            text = "00:00:00"
            textSize = 16f
            setTextColor(Color.WHITE)
            setPadding(20, 12, 20, 12)
            background = GradientDrawable().apply {
                setColor(0xEE171717.toInt())
                cornerRadius = 48f
                setStroke(1, 0x55FFFFFF)
            }
            elevation = 10f
            setOnTouchListener { _, event -> handleTouch(event) }
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 24
            y = 180
        }

        windowManager.addView(timerView, params)
        attached = true
    }

    private fun startAsForeground() {
        val channelId = "floating_timer_channel"
        val manager = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            manager.createNotificationChannel(
                NotificationChannel(channelId, "Floating Timer", NotificationManager.IMPORTANCE_LOW)
            )
        }
        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, channelId)
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
        }
        val notification: Notification = builder
            .setContentTitle("Floating Timer ativo")
            .setContentText("Toque na cápsula para iniciar ou pausar")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setOngoing(true)
            .build()
        startForeground(7, notification)
    }

    private fun handleTouch(event: MotionEvent): Boolean {
        val params = timerView.layoutParams as WindowManager.LayoutParams
        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                downRawX = event.rawX.toInt()
                downRawY = event.rawY.toInt()
                initialX = params.x
                initialY = params.y
                moved = false
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = event.rawX.toInt() - downRawX
                val dy = event.rawY.toInt() - downRawY
                if (abs(dx) > 10 || abs(dy) > 10) moved = true
                if (moved) {
                    params.x = initialX + dx
                    params.y = initialY + dy
                    windowManager.updateViewLayout(timerView, params)
                }
                return true
            }
            MotionEvent.ACTION_UP -> {
                if (!moved) registerTap()
                return true
            }
        }
        return true
    }

    private fun registerTap() {
        val previous = pendingTap
        if (previous != null) {
            handler.removeCallbacks(previous)
            pendingTap = null
            resetAndStart()
        } else {
            val singleTap = Runnable {
                pendingTap = null
                if (running) pauseTimer() else startTimer()
            }
            pendingTap = singleTap
            handler.postDelayed(singleTap, 280L)
        }
    }

    private fun startTimer() {
        if (!running) {
            startedAt = System.currentTimeMillis()
            running = true
            handler.removeCallbacks(ticker)
            handler.post(ticker)
        }
    }

    private fun pauseTimer() {
        if (running) {
            elapsedBeforeStart += System.currentTimeMillis() - startedAt
            running = false
            handler.removeCallbacks(ticker)
            renderTime()
        }
    }

    private fun resetAndStart() {
        elapsedBeforeStart = 0L
        startedAt = System.currentTimeMillis()
        running = true
        handler.removeCallbacks(ticker)
        handler.post(ticker)
        renderTime()
    }

    private fun renderTime() {
        val elapsed = elapsedBeforeStart +
            if (running) System.currentTimeMillis() - startedAt else 0L
        val totalSeconds = elapsed / 1000L
        val hours = totalSeconds / 3600L
        val minutes = (totalSeconds % 3600L) / 60L
        val seconds = totalSeconds % 60L
        timerView.text = String.format("%02d:%02d:%02d", hours, minutes, seconds)
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        if (attached) {
            windowManager.removeView(timerView)
            attached = false
        }
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
