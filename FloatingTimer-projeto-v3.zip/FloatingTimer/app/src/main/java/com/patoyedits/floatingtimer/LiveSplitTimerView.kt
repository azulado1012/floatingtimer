package com.patoyedits.floatingtimer

import android.content.Context
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.util.TypedValue
import android.view.View
import java.util.Locale

/** Visual do timer idêntico ao LiveSplit: dígitos verdes em degradê e centésimos menores. */
class LiveSplitTimerView(context: Context) : View(context) {

    enum class State { IDLE, RUNNING, PAUSED }

    private val dm = context.resources.displayMetrics

    private fun sp(v: Float) = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, v, dm)
    private fun dp(v: Float) = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, dm)

    private val mainPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        textSize = sp(40f)
    }
    private val decimalPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        textSize = sp(24f)
    }

    private var mainText = "0"
    private var decimalText = ".00"
    private var state = State.IDLE

    private val padH = dp(14f)
    private val padV = dp(4f)

    init {
        background = GradientDrawable().apply {
            setColor(0xFF0F0F0F.toInt())
            cornerRadius = dp(4f)
            setStroke(dp(1f).toInt().coerceAtLeast(1), 0x22FFFFFF)
        }
        elevation = dp(4f)
    }

    fun setState(newState: State) {
        if (state != newState) {
            state = newState
            updateShader()
            invalidate()
        }
    }

    fun setElapsed(ms: Long) {
        val totalCs = ms / 10L
        val cs = totalCs % 100L
        val totalSec = totalCs / 100L
        val s = totalSec % 60L
        val m = (totalSec / 60L) % 60L
        val h = totalSec / 3600L
        val newMain = when {
            h > 0L -> String.format(Locale.US, "%d:%02d:%02d", h, m, s)
            m > 0L -> String.format(Locale.US, "%d:%02d", m, s)
            else -> String.format(Locale.US, "%d", s)
        }
        val newDecimal = String.format(Locale.US, ".%02d", cs)
        val lengthChanged = newMain.length != mainText.length
        mainText = newMain
        decimalText = newDecimal
        if (lengthChanged) requestLayout()
        invalidate()
    }

    private fun updateShader() {
        val (top, bottom) = when (state) {
            State.IDLE -> 0xFFEDEDED.toInt() to 0xFFA6A6A6.toInt()
            State.RUNNING -> 0xFF5CE07E.toInt() to 0xFF1FB246.toInt()
            State.PAUSED -> 0xFFB0B0B0.toInt() to 0xFF6E6E6E.toInt()
        }
        val fm = mainPaint.fontMetrics
        val y0 = padV + 0f
        val y1 = padV + (fm.descent - fm.ascent)
        val shader = LinearGradient(0f, y0, 0f, y1, top, bottom, Shader.TileMode.CLAMP)
        mainPaint.shader = shader
        decimalPaint.shader = shader
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val fm = mainPaint.fontMetrics
        val w = padH * 2 + mainPaint.measureText(mainText) + decimalPaint.measureText(decimalText)
        val h = padV * 2 + (fm.descent - fm.ascent)
        setMeasuredDimension(
            resolveSize(w.toInt() + 1, widthMeasureSpec),
            resolveSize(h.toInt() + 1, heightMeasureSpec)
        )
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        updateShader()
    }

    override fun onDraw(canvas: Canvas) {
        val fm = mainPaint.fontMetrics
        val baseline = padV - fm.ascent
        val mainWidth = mainPaint.measureText(mainText)
        canvas.drawText(mainText, padH, baseline, mainPaint)
        canvas.drawText(decimalText, padH + mainWidth, baseline, decimalPaint)
    }
}
