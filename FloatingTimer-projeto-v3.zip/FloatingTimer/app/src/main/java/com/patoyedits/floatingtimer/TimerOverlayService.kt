package com.patoyedits.floatingtimer

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.graphics.drawable.Icon
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.view.MotionEvent
import android.view.ViewConfiguration
import android.view.WindowManager
import kotlin.math.abs
import kotlin.math.max

class TimerOverlayService : Service() {

    companion object {
        const val ACTION_STOP = "com.patoyedits.floatingtimer.ACTION_STOP"
        private const val DOUBLE_TAP_WINDOW_MS = 300L
        private const val FRAME_MS = 16L
    }

    private lateinit var windowManager: WindowManager
    private lateinit var timerView: LiveSplitTimerView
    private lateinit var layoutParams: WindowManager.LayoutParams
    private val handler = Handler(Looper.getMainLooper())

    private var state = LiveSplitTimerView.State.IDLE
    private var startedAt = 0L
    private var elapsedBeforeStart = 0L
    private var attached = false

    private var lastTapAt = 0L
    private var downRawX = 0f
    private var downRawY = 0f
    private var initialX = 0
    private var initialY = 0
    private var moved = false
    private var touchSlop = 0

    private val ticker = object : Runnable {
        override fun run() {
            if (state == LiveSplitTimerView.State.RUNNING) {
                timerView.setElapsed(currentElapsed())
                handler.postDelayed(this, FRAME_MS)
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        startAsForeground()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        touchSlop = ViewConfiguration.get(this).scaledTouchSlop

        timerView = LiveSplitTimerView(this).apply {
            setElapsed(0L)
            setState(LiveSplitTimerView.State.IDLE)
            setOnTouchListener { _, event -> handleTouch(event) }
        }

        val density = resources.displayMetrics.density
        layoutParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = (24 * density).toInt()
            y = (120 * density).toInt()
        }

        windowManager.addView(timerView, layoutParams)
        attached = true
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        return START_STICKY
    }

    private fun startAsForeground() {
        val channelId = "floating_timer_channel"
        val manager = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            manager.createNotificationChannel(
                NotificationChannel(channelId, "Floating Timer", NotificationManager.IMPORTANCE_LOW)
            )
        }
        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, channelId)
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
        }

        val stopIntent = Intent(this, TimerOverlayService::class.java).setAction(ACTION_STOP)
        var piFlags = PendingIntent.FLAG_UPDATE_CURRENT
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) piFlags = piFlags or PendingIntent.FLAG_IMMUTABLE
        val stopPending = PendingIntent.getService(this, 1, stopIntent, piFlags)
        val stopAction = Notification.Action.Builder(
            Icon.createWithResource(this, android.R.drawable.ic_menu_close_clear_cancel),
            "Fechar",
            stopPending
        ).build()

        val notification: Notification = builder
            .setContentTitle("Floating Timer ativo")
            .setContentText("1 toque: iniciar/pausar  •  2 toques: zerar")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setOngoing(true)
            .addAction(stopAction)
            .build()
        startForeground(7, notification)
    }

    private fun handleTouch(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downRawX = event.rawX
                downRawY = event.rawY
                initialX = layoutParams.x
                initialY = layoutParams.y
                moved = false
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = event.rawX - downRawX
                val dy = event.rawY - downRawY
                if (!moved && (abs(dx) > touchSlop || abs(dy) > touchSlop)) moved = true
                if (moved) {
                    val dm = resources.displayMetrics
                    val maxX = max(0, dm.widthPixels - timerView.width)
                    val maxY = max(0, dm.heightPixels - timerView.height)
                    layoutParams.x = (initialX + dx).toInt().coerceIn(0, maxX)
                    layoutParams.y = (initialY + dy).toInt().coerceIn(0, maxY)
                    windowManager.updateViewLayout(timerView, layoutParams)
                }
            }
            MotionEvent.ACTION_UP -> {
                if (!moved) registerTap()
            }
        }
        return true
    }

    /**
     * Sem atraso: o toque age na hora (precisão de cronômetro).
     * Se vier um segundo toque em até 300 ms, zera e NÃO inicia.
     */
    private fun registerTap() {
        val now = SystemClock.elapsedRealtime()
        if (lastTapAt != 0L && now - lastTapAt <= DOUBLE_TAP_WINDOW_MS) {
            lastTapAt = 0L
            resetTimer()
        } else {
            lastTapAt = now
            when (state) {
                LiveSplitTimerView.State.IDLE,
                LiveSplitTimerView.State.PAUSED -> startTimer()
                LiveSplitTimerView.State.RUNNING -> pauseTimer()
            }
        }
    }

    private fun currentElapsed(): Long =
        elapsedBeforeStart +
            if (state == LiveSplitTimerView.State.RUNNING) SystemClock.elapsedRealtime() - startedAt else 0L

    private fun startTimer() {
        startedAt = SystemClock.elapsedRealtime()
        state = LiveSplitTimerView.State.RUNNING
        timerView.setState(state)
        handler.removeCallbacks(ticker)
        handler.post(ticker)
    }

    private fun pauseTimer() {
        elapsedBeforeStart = currentElapsed()
        state = LiveSplitTimerView.State.PAUSED
        handler.removeCallbacks(ticker)
        timerView.setState(state)
        timerView.setElapsed(elapsedBeforeStart)
    }

    private fun resetTimer() {
        handler.removeCallbacks(ticker)
        elapsedBeforeStart = 0L
        startedAt = 0L
        state = LiveSplitTimerView.State.IDLE
        timerView.setState(state)
        timerView.setElapsed(0L)
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        if (attached) {
            windowManager.removeView(timerView)
            attached = false
        }
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
